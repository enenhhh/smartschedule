package com.enenhhh.smartschedule.data

import android.content.Context
import com.enenhhh.smartschedule.util.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ScheduleRepository(private val context: Context) {

    private val odd = WeekSchedule()
    private val even = WeekSchedule()

    private val file: File by lazy {
        File(context.getExternalFilesDir(null), "schedule.json")
    }

    init {
        if (file.exists()) {
            load()
        } else {
            initDefault()
            persist()
        }
    }

    fun getDayEntry(day: String, oddWeek: Boolean): DayEntry {
        val ws = if (oddWeek) odd else even
        return ws.getOrCreate(day).copy( // 返回副本供 UI 使用
            morningRead = ws.getOrCreate(day).morningRead,
            courses = ws.getOrCreate(day).courses.toMutableList()
        )
    }

    fun updateDayEntry(day: String, oddWeek: Boolean, morningRead: String?, courses: List<String>) {
        val ws = if (oddWeek) odd else even
        val entry = ws.getOrCreate(day)
        entry.morningRead = morningRead?.ifBlank { null }
        entry.courses.clear()
        // 只保留实际有内容的课程
        courses.forEachIndexed { index, course ->
            if (index < Prefs.getCourseCount(context) && course.isNotBlank()) {
                if (index < entry.courses.size) {
                    entry.courses[index] = course
                } else {
                    entry.courses.add(course)
                }
            }
        }
        // 确保课程数量正确
        while (entry.courses.size > Prefs.getCourseCount(context)) {
            entry.courses.removeAt(entry.courses.size - 1)
        }
        while (entry.courses.size < Prefs.getCourseCount(context)) {
            entry.courses.add("")
        }
    }

    fun persist() {
        val root = JSONObject()
        root.put("odd", weekToJson(odd))
        root.put("even", weekToJson(even))
        file.writeText(root.toString(2))
    }

    private fun load() {
        val content = file.readText()
        val root = JSONObject(content)
        jsonToWeek(root.optJSONObject("odd"), odd)
        jsonToWeek(root.optJSONObject("even"), even)
        
        // 确保加载后课程数量正确
        val courseCount = Prefs.getCourseCount(context)
        odd.days.values.forEach { entry ->
            while (entry.courses.size < courseCount) {
                entry.courses.add("")
            }
            while (entry.courses.size > courseCount) {
                entry.courses.removeAt(entry.courses.size - 1)
            }
        }
        even.days.values.forEach { entry ->
            while (entry.courses.size < courseCount) {
                entry.courses.add("")
            }
            while (entry.courses.size > courseCount) {
                entry.courses.removeAt(entry.courses.size - 1)
            }
        }
    }

    private fun weekToJson(week: WeekSchedule): JSONObject {
        val obj = JSONObject()
        week.days.forEach { (day, entry) ->
            val d = JSONObject()
            d.put("morningRead", entry.morningRead ?: JSONObject.NULL)
            val arr = JSONArray()
            entry.courses.forEach { arr.put(it) }
            d.put("courses", arr)
            obj.put(day, d)
        }
        return obj
    }

    private fun jsonToWeek(obj: JSONObject?, week: WeekSchedule) {
        week.days.clear()
        if (obj == null) return
        val keys = obj.keys()
        while (keys.hasNext()) {
            val day = keys.next()
            val d = obj.optJSONObject(day) ?: continue
            val entry = DayEntry()
            entry.morningRead = d.optString("morningRead").takeIf { it != "null" && it.isNotBlank() }
            val arr = d.optJSONArray("courses") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val name = arr.optString(i)
                if (name.isNotBlank()) entry.courses.add(name)
            }
            week.days[day] = entry
        }
    }

    private fun initDefault() {
        val days = listOf("周一", "周二", "周三", "周四", "周五")
        val defaultCourseCount = Prefs.getCourseCount(context)

        // 默认课程（单周/双周基本相同；仅周一早读单双不同）
        val default: Map<String, List<String>> = mapOf(
            "周一" to listOf("数学","美术","班会","英语","生物","语文","道法","数学"),
            "周二" to listOf("语文","数学","英语","地理","历史","物理","体育","物理"),
            "周三" to listOf("生物","信息","语文","数学","体育","英语","物理","语文"),
            "周四" to listOf("道法","地理","数学","体育","英语","生物","语文","英语"),
            "周五" to listOf("英语","数学","地理","语文","音乐","历史","物理") // 7节
        )
        val mrOdd: Map<String, String?> = mapOf(
            "周一" to "道法",
            "周二" to "语文",
            "周三" to "生物",
            "周四" to "英语",
            "周五" to "数学"
        )
        val mrEven: Map<String, String?> = mapOf(
            "周一" to "历史", // 单周道法 / 双周历史
            "周二" to "语文",
            "周三" to "英语",
            "周四" to "地理",
            "周五" to "数学"
        )

        days.forEach { day ->
            val defaultCourses = default[day]?.toMutableList() ?: mutableListOf()
            // 确保课程数量正确
            while (defaultCourses.size < defaultCourseCount) {
                defaultCourses.add("")
            }
            while (defaultCourses.size > defaultCourseCount) {
                defaultCourses.removeAt(defaultCourses.size - 1)
            }
            
            odd.days[day] = DayEntry(
                morningRead = mrOdd[day],
                courses = defaultCourses
            )
            even.days[day] = DayEntry(
                morningRead = mrEven[day],
                courses = defaultCourses.toMutableList()
            )
        }
    }

    // 课程简称（用于通知栏）
    fun shortName(name: String): String {
        val customShortNames = Prefs.getCustomShortNames(context)
        if (customShortNames.containsKey(name)) {
            return customShortNames[name] ?: ""
        }
        
        val defaultMap = mapOf(
            "语文" to "语",
            "数学" to "数",
            "英语" to "英",
            "生物" to "生",
            "物理" to "物",
            "化学" to "化",
            "道法" to "道",
            "历史" to "历",
            "地理" to "地",
            "政治" to "政",
            "体育" to "体",
            "美术" to "美",
            "音乐" to "音",
            "信息" to "信",
            "班会" to "班",
            "自习" to "自"
        )
        return defaultMap[name] ?: name.firstOrNull()?.toString() ?: ""
    }

    fun buildTomorrowSummary(nowMillis: Long = System.currentTimeMillis()): String {
        val (label, mr, list) = buildTomorrowData(nowMillis)
        val mrPart = if (!mr.isNullOrBlank()) shortName(mr) else ""
        val shorts = list.map { shortName(it) }
        
        val splitPositions = Prefs.getSplitPositions(context)
        val parts = mutableListOf<String>()
        
        if (mrPart.isNotBlank()) {
            parts.add(mrPart)
        }
        
        var startIndex = 0
        splitPositions.forEach { position ->
            if (position > startIndex && position <= shorts.size) {
                val part = shorts.subList(startIndex, position).joinToString(" ")
                if (part.isNotBlank()) {
                    parts.add(part)
                }
                startIndex = position
            }
        }
        
        // 添加剩余部分
        if (startIndex < shorts.size) {
            val part = shorts.subList(startIndex, shorts.size).joinToString(" ")
            if (part.isNotBlank()) {
                parts.add(part)
            }
        }
        
        return if (parts.isEmpty()) {
            "明天（$label）：无课"
        } else {
            "明天（$label）：${parts.joinToString(Prefs.getSplitSeparator(context))}"
        }
    }

    data class TomorrowData(val label: String, val morning: String?, val courses: List<String>)

    private fun buildTomorrowData(nowMillis: Long): TomorrowData {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = nowMillis }
        cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        val weekday = cal.get(java.util.Calendar.DAY_OF_WEEK) // 1=周日,2=周一...
        val label = when (weekday) {
            java.util.Calendar.MONDAY -> "周一"
            java.util.Calendar.TUESDAY -> "周二"
            java.util.Calendar.WEDNESDAY -> "周三"
            java.util.Calendar.THURSDAY -> "周四"
            java.util.Calendar.FRIDAY -> "周五"
            java.util.Calendar.SATURDAY -> "周六"
            else -> "周日"
        }

        val isOddWeek = com.enenhhh.smartschedule.util.DateUtils.isOddWeekRelativeTo(cal.timeInMillis,
            com.enenhhh.smartschedule.util.Prefs.getStartDate(context))
        return if (label in listOf("周一","周二","周三","周四","周五")) {
            val entry = getDayEntry(label, isOddWeek)
            TomorrowData(label, entry.morningRead, entry.courses)
        } else {
            TomorrowData(label, null, emptyList())
        }
    }
}
