package com.enenhhh.smartschedule.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.enenhhh.smartschedule.notifications.NotificationHelper
import com.enenhhh.smartschedule.services.KeepAliveService
import com.enenhhh.smartschedule.util.Prefs

class UpdatePersistentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Prefs.isPersistentEnabled(context) || Prefs.isKeepAlive(context)) {
            KeepAliveService.requestUpdate(context)
        }
        // 保证每天都有更新计划
        NotificationHelper.scheduleDailyPersistentUpdate(context)
    }
}