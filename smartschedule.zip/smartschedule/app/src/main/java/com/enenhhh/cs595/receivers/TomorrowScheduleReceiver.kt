package com.enenhhh.smartschedule.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.enenhhh.smartschedule.notifications.NotificationHelper

class TomorrowScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val nm = NotificationManagerCompat.from(context)
        val notif = NotificationHelper.buildTomorrowPush(context).build()
        nm.notify(NotificationHelper.NOTIF_ID_TOMORROW_PUSH, notif)

        // 触发后安排下一次，且顺便刷新常驻
        NotificationHelper.scheduleTomorrowReminder(context)
        NotificationHelper.triggerPersistentUpdateNow(context)
    }
}