package com.enenhhh.smartschedule.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.result.ActivityResultLauncher
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.enenhhh.smartschedule.R
import com.enenhhh.smartschedule.data.ScheduleRepository
import com.enenhhh.smartschedule.receivers.TomorrowScheduleReceiver
import com.enenhhh.smartschedule.receivers.UpdatePersistentReceiver
import com.enenhhh.smartschedule.receivers.WeatherReceiver
import com.enenhhh.smartschedule.util.Prefs
import java.util.Calendar
import kotlin.concurrent.thread

object NotificationHelper {

    const val CHANNEL_REMINDERS = "schedule_reminders"
    const val CHANNEL_PERSISTENT = "persistent"
    const val CHANNEL_WEATHER = "weather"

    const val NOTIF_ID_TOMORROW_PUSH = 1001
    const val NOTIF_ID_PERSISTENT = 2001
    const val NOTIF_ID_WEATHER = 3001

    fun createChannels(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)

        val reminders = NotificationChannelCompat.Builder(
            CHANNEL_REMINDERS,
            NotificationManagerCompat.IMPORTANCE_DEFAULT
        ).setName("课表提醒")
            .setDescription("明日课表推送")
            .build()

        val persistent = NotificationChannelCompat.Builder(
            CHANNEL_PERSISTENT,
            NotificationManagerCompat.IMPORTANCE_LOW
        ).setName("常驻通知")
            .setDescription("常驻明日课表或保活通知")
            .build()

        val weather = NotificationChannelCompat.Builder(
            CHANNEL_WEATHER,
            NotificationManagerCompat.IMPORTANCE_DEFAULT
        ).setName("天气提醒")
            .setDescription("明天天气推送")
            .build()

        nm.createNotificationChannel(reminders)
        nm.createNotificationChannel(persistent)
        nm.createNotificationChannel(weather)
    }

    fun maybeRequestPostNotifications(ctx: Context, launcher: ActivityResultLauncher<String>) {
        if (Build.VERSION.SDK_INT >= 33) {
            val nm = NotificationManagerCompat.from(ctx)
            if (!nm.areNotificationsEnabled()) {
                launcher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // ---------- 课表推送（明日） ----------
    fun scheduleTomorrowReminder(ctx: Context) {
        if (!Prefs.isTomorrowReminderEnabled(ctx)) return

        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, TomorrowScheduleReceiver::class.java).apply {
            action = "com.enenhhh.smartschedule.ACTION_TOMORROW_SCHEDULE"
        }
        val pi = PendingIntent.getBroadcast(
            ctx, 100, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            set(Calendar.HOUR_OF_DAY, Prefs.getReminderHour(ctx))
            set(Calendar.MINUTE, Prefs.getReminderMinute(ctx))
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        setExact(am, cal.timeInMillis, pi)
    }

    fun cancelTomorrowReminder(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, TomorrowScheduleReceiver::class.java).apply {
            action = "com.enenhhh.smartschedule.ACTION_TOMORROW_SCHEDULE"
        }
        val pi = PendingIntent.getBroadcast(
            ctx, 100, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun buildTomorrowPush(ctx: Context): NotificationCompat.Builder {
        val repo = ScheduleRepository(ctx)
        val content = repo.buildTomorrowSummary()
        return NotificationCompat.Builder(ctx, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("明日课表")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
    }

    fun triggerScheduleNow(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        val notif = buildTomorrowPush(ctx).build()
        nm.notify(NOTIF_ID_TOMORROW_PUSH, notif)
        // 手动触发也顺带刷新常驻
        triggerPersistentUpdateNow(ctx)
    }

    // ---------- 天气推送（明天） ----------
    fun scheduleWeatherReminder(ctx: Context) {
        if (!Prefs.isWeatherReminderEnabled(ctx)) return

        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, WeatherReceiver::class.java).apply {
            action = "com.enenhhh.smartschedule.ACTION_TOMORROW_WEATHER"
        }
        val pi = PendingIntent.getBroadcast(
            ctx, 300, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            set(Calendar.HOUR_OF_DAY, Prefs.getWeatherHour(ctx))
            set(Calendar.MINUTE, Prefs.getWeatherMinute(ctx))
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        setExact(am, cal.timeInMillis, pi)
    }

    fun cancelWeatherReminder(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, WeatherReceiver::class.java).apply {
            action = "com.enenhhh.smartschedule.ACTION_TOMORROW_WEATHER"
        }
        val pi = PendingIntent.getBroadcast(
            ctx, 300, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun triggerWeatherNow(ctx: Context) {
        thread {
            val content = com.enenhhh.smartschedule.weather.WeatherFetcher.fetchTomorrowSummary(ctx)
            val builder = NotificationCompat.Builder(ctx, CHANNEL_WEATHER)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("明天天气")
                .setContentText(content)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            NotificationManagerCompat.from(ctx).notify(NOTIF_ID_WEATHER, builder.build())
        }
    }

    // ---------- 常驻通知更新（每日 00:01） ----------
    fun scheduleDailyPersistentUpdate(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, UpdatePersistentReceiver::class.java).apply {
            action = "com.enenhhh.smartschedule.ACTION_UPDATE_PERSISTENT"
        }
        val pi = PendingIntent.getBroadcast(
            ctx, 200, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 1)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        setExact(am, cal.timeInMillis, pi)
    }

    fun buildPersistentNotification(ctx: Context): NotificationCompat.Builder {
        val repo = ScheduleRepository(ctx)
        val persistentEnabled = Prefs.isPersistentEnabled(ctx)
        val content = if (persistentEnabled) {
            repo.buildTomorrowSummary()
        } else {
            "应用保持后台运行中"
        }
        return NotificationCompat.Builder(ctx, CHANNEL_PERSISTENT)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(if (persistentEnabled) "常驻明日课表" else "后台保活")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
    }

    fun triggerPersistentUpdateNow(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        val notif = buildPersistentNotification(ctx).build()
        nm.notify(NOTIF_ID_PERSISTENT, notif)
    }

    // ---------- 内部：设置精确闹钟 ----------
    private fun setExact(am: AlarmManager, triggerAt: Long, pi: PendingIntent) {
        if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }
}