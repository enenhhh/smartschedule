package com.enenhhh.smartschedule

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.enenhhh.smartschedule.data.ScheduleRepository
import com.enenhhh.smartschedule.databinding.ActivityEditScheduleBinding
import com.enenhhh.smartschedule.services.KeepAliveService
import com.enenhhh.smartschedule.util.Prefs
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class EditScheduleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditScheduleBinding
    private lateinit var repo: ScheduleRepository

    private var currentDay = "周一"
    private var currentOdd = true
    private val courseInputs = mutableListOf<TextInputEditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditScheduleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        repo = ScheduleRepository(this)

        // 初始化课程输入框列表
        initCourseInputsList()

        // 日选择
        val days = listOf("周一", "周二", "周三", "周四", "周五")
        binding.spinnerDay.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, days)
        binding.spinnerDay.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                currentDay = days[pos]
                loadFields()
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }

        // 单/双
        binding.toggleWeekType.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                currentOdd = checkedId == binding.btnOdd.id
                loadFields()
            }
        }

        binding.btnSave.setOnClickListener {
            // 读取并保存当前界面对应（单/双 + day）的数据
            saveCurrentFields()
            repo.persist()
            // 更新常驻通知内容
            KeepAliveService.requestUpdate(this)
            finish()
        }

        // 默认显示 周一 单周
        binding.spinnerDay.setSelection(0)
        binding.toggleWeekType.check(binding.btnOdd.id)
        loadFields()
    }

    private fun initCourseInputsList() {
        // 清空列表
        courseInputs.clear()
        
        // 添加所有8个固定的课程输入框
        courseInputs.addAll(listOf(
            binding.et1, binding.et2, binding.et3, binding.et4,
            binding.et5, binding.et6, binding.et7, binding.et8
        ))
    }

    private fun loadFields() {
        val entry = repo.getDayEntry(currentDay, currentOdd)
        
        // 设置早读
        binding.etMr.setText(entry.morningRead ?: "")

        // 清空所有课程输入框
        courseInputs.forEach { it.setText("") }
        
        // 填充课程数据
        entry.courses.forEachIndexed { idx, name ->
            if (idx < courseInputs.size) {
                courseInputs[idx].setText(name)
            }
        }

        // 更新提示文本
        val courseCount = Prefs.getCourseCount(this)
        binding.tipCourseCount.text = "当前设置：${courseCount}节课（可在设置中调整）"
        
        // 周五提示
        binding.tipFriday.visibility = if (currentDay == "周五") View.VISIBLE else View.GONE
    }

    private fun saveCurrentFields() {
        val mr = binding.etMr.text?.toString()?.trim().orEmpty()
        
        // 获取所有课程输入框的内容
        val list = courseInputs.map { it.text?.toString()?.trim().orEmpty() }
            .dropLastWhile { it.isBlank() } // 去掉末尾空白

        repo.updateDayEntry(currentDay, currentOdd, mr.ifBlank { "" }, list)
    }
}
