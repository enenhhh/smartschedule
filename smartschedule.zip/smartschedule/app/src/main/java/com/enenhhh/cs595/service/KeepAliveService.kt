package com.enenhhh.smartschedule.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import com.enenhhh.smartschedule.notifications.NotificationHelper
import com.enenhhh.smartschedule.util.Prefs

class KeepAliveService : Service() {

    companion object {
        private const val ACTION_UPDATE = "ACTION_UPDATE"
        fun start(ctx: Context) {
            NotificationHelper.createChannels(ctx)
            val i = Intent(ctx, KeepAliveService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
            // 确保每日更新安排
            NotificationHelper.scheduleDailyPersistentUpdate(ctx)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, KeepAliveService::class.java))
        }

        fun requestUpdate(ctx: Context) {
            val i = Intent(ctx, KeepAliveService::class.java).apply { action = ACTION_UPDATE }
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = NotificationManagerCompat.from(this)
        val builder = NotificationHelper.buildPersistentNotification(this)
        val notif = builder.build()
        startForeground(NotificationHelper.NOTIF_ID_PERSISTENT, notif)

        // 若两个开关全关，则停止
        if (!Prefs.isPersistentEnabled(this) && !Prefs.isKeepAlive(this)) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(p0: Intent?): IBinder? = null
}