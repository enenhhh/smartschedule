package com.enenhhh.smartschedule

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.enenhhh.smartschedule.databinding.ActivitySettingsBinding
import com.enenhhh.smartschedule.notifications.NotificationHelper
import com.enenhhh.smartschedule.services.KeepAliveService
import com.enenhhh.smartschedule.util.Prefs
import java.util.Calendar

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            NotificationHelper.createChannels(this)
            // 权限授予后重新设置提醒
            if (binding.switchReminder.isChecked) {
                NotificationHelper.scheduleTomorrowReminder(this)
            }
            if (binding.switchWeather.isChecked) {
                NotificationHelper.scheduleWeatherReminder(this)
            }
        } else {
            // 如果拒绝权限，关闭两个提醒开关
            binding.switchReminder.isChecked = false
            Prefs.setTomorrowReminderEnabled(this, false)
            binding.switchWeather.isChecked = false
            Prefs.setWeatherReminderEnabled(this, false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // 初始化显示
        binding.tvDataPath.text = "数据保存在：/Android/data/${packageName}/files"
        binding.tvStartDate.text = Prefs.getStartDate(this).replace('-', '/')

        // 版本/作者/反馈
        val pInfo = packageManager.getPackageInfo(packageName, 0)
        binding.tvVersion.text = "版本号：${pInfo.versionName ?: "1.0"}"
        binding.tvAuthor.text = "作者：恩恩hhh"
        binding.tvFeedback.text = "意见反馈：https://www.wjx.cn/vm/rm8uWLo.aspx"
        
        // 使反馈链接可点击
        binding.tvFeedback.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.wjx.cn/vm/rm8uWLo.aspx"))
            startActivity(intent)
        }

        // 状态初始化
        binding.switchKeepAlive.isChecked = Prefs.isKeepAlive(this)
        binding.switchPersistent.isChecked = Prefs.isPersistentEnabled(this)

        binding.switchReminder.isChecked = Prefs.isTomorrowReminderEnabled(this)
        binding.tvReminderTime.text = "%02d:%02d".format(Prefs.getReminderHour(this), Prefs.getReminderMinute(this))

        binding.switchWeather.isChecked = Prefs.isWeatherReminderEnabled(this)
        binding.tvWeatherTime.text = "%02d:%02d".format(Prefs.getWeatherHour(this), Prefs.getWeatherMinute(this))
        binding.tvCity.text = Prefs.getWeatherCity(this)

        // 新增设置初始化
        binding.tvCourseCount.text = "当前：${Prefs.getCourseCount(this)}节课"
        binding.tvSplitPositions.text = "当前：${Prefs.getSplitPositions(this).joinToString(",")}"
        binding.tvSplitSeparator.text = "当前：\"${Prefs.getSplitSeparator(this)}\""

        // 事件监听器
        binding.btnEditSchedule.setOnClickListener {
            startActivity(Intent(this, EditScheduleActivity::class.java))
        }

        binding.switchKeepAlive.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setKeepAlive(this, isChecked)
            if (isChecked) {
                KeepAliveService.start(this)
            } else {
                if (!Prefs.isPersistentEnabled(this)) {
                    KeepAliveService.stop(this)
                } else {
                    KeepAliveService.requestUpdate(this)
                }
            }
        }

        binding.switchPersistent.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setPersistentEnabled(this, isChecked)
            if (isChecked) {
                KeepAliveService.start(this)
            } else {
                if (Prefs.isKeepAlive(this)) {
                    KeepAliveService.requestUpdate(this)
                } else {
                    KeepAliveService.stop(this)
                }
            }
        }

        // 课表提醒时间
        binding.rowReminderTime.setOnClickListener {
            val h = Prefs.getReminderHour(this)
            val m = Prefs.getReminderMinute(this)
            TimePickerDialog(this, { _, hourOfDay, minute ->
                Prefs.setReminderTime(this, hourOfDay, minute)
                binding.tvReminderTime.text = "%02d:%02d".format(hourOfDay, minute)
                NotificationHelper.scheduleTomorrowReminder(this)
            }, h, m, true).show()
        }

        // 课表提醒开关
        binding.switchReminder.setOnCheckedChangeListener { _, checked ->
            Prefs.setTomorrowReminderEnabled(this, checked)
            if (checked) {
                NotificationHelper.maybeRequestPostNotifications(this, notifPermissionLauncher)
                NotificationHelper.scheduleTomorrowReminder(this)
            } else {
                NotificationHelper.cancelTomorrowReminder(this)
            }
        }

        // 天气提醒时间
        binding.rowWeatherTime.setOnClickListener {
            val h = Prefs.getWeatherHour(this)
            val m = Prefs.getWeatherMinute(this)
            TimePickerDialog(this, { _, hourOfDay, minute ->
                Prefs.setWeatherTime(this, hourOfDay, minute)
                binding.tvWeatherTime.text = "%02d:%02d".format(hourOfDay, minute)
                NotificationHelper.scheduleWeatherReminder(this)
            }, h, m, true).show()
        }

        // 天气提醒开关
        binding.switchWeather.setOnCheckedChangeListener { _, checked ->
            Prefs.setWeatherReminderEnabled(this, checked)
            if (checked) {
                NotificationHelper.maybeRequestPostNotifications(this, notifPermissionLauncher)
                NotificationHelper.scheduleWeatherReminder(this)
            } else {
                NotificationHelper.cancelWeatherReminder(this)
            }
        }

        // 设置城市
        binding.rowCity.setOnClickListener {
            val et = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_TEXT
                setText(Prefs.getWeatherCity(this@SettingsActivity))
                hint = "输入城市（如：北京、上海、广州…）"
            }
            AlertDialog.Builder(this)
                .setTitle("设置城市")
                .setView(et)
                .setPositiveButton("确定") { _, _ ->
                    val city = et.text?.toString()?.trim().orEmpty().ifBlank { "北京" }
                    Prefs.setWeatherCity(this, city)
                    binding.tvCity.text = city
                }
                .setNegativeButton("取消", null)
                .show()
        }

        // 学期开始日期
        binding.rowStartDate.setOnClickListener {
            val cur = Prefs.getStartDateCalendar(this)
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    val dateStr = "%04d-%02d-%02d".format(y, m + 1, d)
                    Prefs.setStartDate(this, dateStr)
                    binding.tvStartDate.text = dateStr.replace('-', '/')
                    KeepAliveService.requestUpdate(this)
                },
                cur.get(Calendar.YEAR),
                cur.get(Calendar.MONTH),
                cur.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        // 立即发送
        binding.btnSendScheduleNow.setOnClickListener {
            NotificationHelper.maybeRequestPostNotifications(this, notifPermissionLauncher)
            NotificationHelper.triggerScheduleNow(this)
        }
        
        binding.btnSendWeatherNow.setOnClickListener {
            NotificationHelper.maybeRequestPostNotifications(this, notifPermissionLauncher)
            NotificationHelper.triggerWeatherNow(this)
        }

        // 全局立即更新
        binding.btnRefreshAll.setOnClickListener {
            // 刷新持久通知
            NotificationHelper.triggerPersistentUpdateNow(this)
            // 重设定时器
            NotificationHelper.scheduleDailyPersistentUpdate(this)
            if (Prefs.isTomorrowReminderEnabled(this)) {
                NotificationHelper.scheduleTomorrowReminder(this)
            }
            if (Prefs.isWeatherReminderEnabled(this)) {
                NotificationHelper.scheduleWeatherReminder(this)
            }
        }

        // 新增设置监听器
        binding.rowCourseCount.setOnClickListener {
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(Prefs.getCourseCount(this@SettingsActivity).toString())
            }
            AlertDialog.Builder(this)
                .setTitle("设置课程数量")
                .setView(input)
                .setPositiveButton("确定") { _, _ ->
                    val count = input.text.toString().toIntOrNull() ?: Prefs.getCourseCount(this)
                    Prefs.setCourseCount(this, count)
                    binding.tvCourseCount.text = "当前：${count}节课"
                }
                .setNegativeButton("取消", null)
                .show()
        }

        binding.rowCustomShortNames.setOnClickListener {
            val currentNames = Prefs.getCustomShortNames(this)
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setText(currentNames.entries.joinToString("\n") { "${it.key}=${it.value}" })
                hint = "格式：课程全称=简写\n每行一个"
            }
            AlertDialog.Builder(this)
                .setTitle("自定义课程简写")
                .setView(input)
                .setPositiveButton("确定") { _, _ ->
                    val text = input.text.toString().trim()
                    if (text.isNotBlank()) {
                        val map = mutableMapOf<String, String>()
                        text.split("\n").forEach { line ->
                            val parts = line.split("=", limit = 2)
                            if (parts.size == 2) {
                                map[parts[0].trim()] = parts[1].trim()
                            }
                        }
                        Prefs.setCustomShortNames(this, map)
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        }

        binding.rowSplitPositions.setOnClickListener {
            val currentPositions = Prefs.getSplitPositions(this)
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setText(currentPositions.joinToString(","))
                hint = "输入分割位置（逗号分隔）\n例如：1,5"
            }
            AlertDialog.Builder(this)
                .setTitle("设置分割线位置")
                .setView(input)
                .setPositiveButton("确定") { _, _ ->
                    val text = input.text.toString().trim()
                    if (text.isNotBlank()) {
                        val positions = text.split(",")
                            .mapNotNull { it.trim().toIntOrNull() }
                            .filter { it > 0 }
                            .sorted()
                        Prefs.setSplitPositions(this, positions)
                        binding.tvSplitPositions.text = "当前：${positions.joinToString(",")}"
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        }

        binding.rowSplitSeparator.setOnClickListener {
            val current = Prefs.getSplitSeparator(this)
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_TEXT
                setText(current)
                hint = "输入分割线符号"
            }
            AlertDialog.Builder(this)
                .setTitle("设置分割线符号")
                .setView(input)
                .setPositiveButton("确定") { _, _ ->
                    val separator = input.text.toString().trim()
                    if (separator.isNotBlank()) {
                        Prefs.setSplitSeparator(this, separator)
                        binding.tvSplitSeparator.text = "当前：\"$separator\""
                    }
                }
                .setNegativeButton("取消", null)
                .show()
        }
    }
}
